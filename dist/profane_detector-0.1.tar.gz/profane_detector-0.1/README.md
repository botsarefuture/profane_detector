# ProfanityDetector
A Python library for profanity detection in text, providing a customizable ProfaneDetector class. Easily integrate into your projects to filter or flag content.
